package items;

public enum DigitalDeviceType {
    phone,laptop,smartWatch;
}
