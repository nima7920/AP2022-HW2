package users;

public class Member extends User{

    /**
     * A subclass of user, indicates an ordinary user, with access of buying and selling products
     */
    public Member(String name, long phone) {
        super(name, phone);

    }
}
