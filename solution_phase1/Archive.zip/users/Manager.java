package users;

public class Manager extends User{

    /**
     * A subclass of user, indicates users with access of modifying market
     */
    public Manager(String name, long phone) {
        super(name, phone);
    }
}
