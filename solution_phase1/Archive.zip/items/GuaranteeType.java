package items;

public enum GuaranteeType {
    DigitalDevice,
    Property,
    car;
}
