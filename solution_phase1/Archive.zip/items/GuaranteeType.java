package items;

public enum GuaranteeType {
    digitalDevice,
    property,
    car;
}
