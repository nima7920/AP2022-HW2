package items;

public enum AccountType {
    saving,
    current,
    deposit;

}
