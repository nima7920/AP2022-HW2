package items;

public class BatteryPriceStrategy {
    public double calculatePrice(Battery battery){
        return 0;
    }
}
