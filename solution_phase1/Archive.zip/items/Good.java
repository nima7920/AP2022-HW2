package items;

import market.Market;
import users.User;

public class Good extends Product {

    /**
     * A subclass of product, should have four subclasses: property, car, educationalMaterial and digitalDevice
     */

    public Good(String name, User user) {
        super(name, user);
    }

}
